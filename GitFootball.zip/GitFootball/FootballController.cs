﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using FootballAss.Models;
using System.Data;
using System.Data.Entity;

namespace FootballAss.Controllers
{
    public class FootballController : Controller
    {
        // GET: Football
        FootballContext context = new FootballContext();

        public ActionResult Index()
        {
            context.matchtable.ToList();
            return View();
        }
        [HttpPost]
        public void Insert(string teamname1, string teamname2, string status, string winteam, int points)
        {
            SqlConnection con = new SqlConnection("data source=SHAFI;database=Footballdb;integrated security=SSPI");
            SqlCommand cmd = con.CreateCommand();
            con.Open();
            cmd.CommandText = "Execute Footballsp @TeamName1,@TeamName2,@Status,@WinningTeam,@Points";
            cmd.Parameters.Add("@TeamName1", SqlDbType.VarChar, 50).Value = teamname1;
            cmd.Parameters.Add("@TeamName2", SqlDbType.VarChar, 50).Value = teamname2;
            cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50).Value = status;
            cmd.Parameters.Add("@WinningTeam", SqlDbType.VarChar, 50).Value = winteam;
            cmd.Parameters.Add("@Points", SqlDbType.Int, 4).Value = points;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
        }

     }





    }
