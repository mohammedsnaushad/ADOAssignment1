﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.SqlClient;

namespace FootballAss.Models
{
    public class FootballContext:DbContext
    {
        public FootballContext()
            : base("name =FootballConn")
        {

        }
        public DbSet<Matchdetails> matchtable { get; set; }
    }

}
